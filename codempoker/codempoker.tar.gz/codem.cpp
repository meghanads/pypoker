#include <iostream>
#include <fstream>
#include <cstring>
#include <sys/wait.h>
#include <malloc.h>

#include "lib/pokerlib.cpp"

#define DEBUG 0
#define MAXLINE 1000

using namespace std;

class player {
	public:
	int curstage;
	int curmoney;
	char status;
	int money;
	int card1;
	int card2;
	char** command;
};

// defining players of the game
player p[6];

int deck[52];
int table[5];
int deck_start = 0;


/************************/

bool run_program (int p_num) {

	int seconds = 2;

	pid_t child;
	child = fork();

	if (child == -1) {
		printf("Failed to create child \n");
		return -1;
	}

	if (child == 0) {

		execv(p[p_num].command[0],p[p_num].command);

	}

	else {
		bool done = false;
		clock_t endwait;
		endwait = clock () + seconds * CLOCKS_PER_SEC ;
		while (clock() < endwait) {
			int st;
			int status = waitpid(child,&st,WNOHANG);
			if (status == 0) {
				int ret = WIFEXITED (st);
				if (ret != 0) {
					return false;
				}
				done = true;
				break;
			}
		}
		if (!done) {
		
			//TIMEOUT!!!
			//terminate player
			kill (child, SIGKILL);
			return false;
		}
		else {
			return true;
		}
	}
}

char ** tokenize(char* input);

void input_run_commands () {
	char str[1000];
	for (int i=0; i<6; i++) {
		cin.getline(str,1000);
		p[i].command = tokenize (str);
	}
}


/*the tokenizer function takes a string of chars and forms tokens out of it*/
char ** tokenize(char* input) {
	int i;

	const char *delim = " \t\n";//the delimiters to separate tokens
	char *token, **tokens;

	tokens = (char **) malloc(MAXLINE*sizeof(char*));

	i = 0;
	if(DEBUG) printf("-- Tokens\n");
	while((token = strtok(input, delim)) !=NULL){
		tokens[i] = (char*)malloc(sizeof(char));
		if(tokens[i] == NULL) {fprintf(stderr, "tokens[%d].",i); perror("Cannot malloc");}
		strcpy(tokens[i], token);
		if(DEBUG) printf("   %d:%s \n",i,tokens[i]);//for debugging
		if(i==0) input = NULL;//input to strtok should be NULL after first call
		i++;
	}
	tokens[i] = NULL;

	return tokens; 
}





/*********************/

int evaluate_hand (int c1, int c2) {
	int hand[7];
	hand[0] = c1;
	hand[1] = c2;
	for (int i=2; i<7; i++) hand[i] = table[i-2];
	return eval_7hand(hand);
}


int get_card () {
	deck_start++;
	return deck [deck_start-1];
}

void prepare_deck () {
	deck_start = 0;
	init_deck (deck);		
	shuffle_deck (deck);
}

void deal_cards (int dealer) {
	int end = (dealer-1)>=0?(dealer-1):5;
	int i = dealer;
	while (i != end) {
		if (p[i].money == 0) continue;
		p[i].card1 = get_card();
		i = (i+1)%6;
	}
	while (i != end) {
		if (p[i].money == 0) continue;
		p[i].card2 = get_card();
		i = (i+1)%6;
	}
	int burn_card = get_card();
	table[0] = get_card();
	table[1] = get_card();
	table[2] = get_card();
	burn_card = get_card();
	table[3] = get_card();
	burn_card = get_card();
	table[4] = get_card();
}

// function to find the last person to call to end the stage
int find_tc (int pl)
{
    int tc = pl-1;
    tc = (tc<1)?6:tc;         
    int k=0;
    while (1)
    {
        if (p[tc-1].money <= 0 || p[tc-1].status == 'f')
        {
            tc--;
            tc = (tc<1)?6:tc;
        }
        else break;
        k++;
        if (k>6)
        {
            tc = 7;
            break;
        }
    }
    return tc;
}

int find_count ()
{
    int j, count=0;
    for(j=0;j<6;j++)
    if (p[j].money <= 0 || p[j].status == 'f') count++;
    return count;
}

int main()
{
    for(int i=0;i<1000;i++)
    {

		int pl, tc, te, tr;
		int potmoney, minraise, stagemoney;

		prepare_deck();

		for (int I=0; I<5; I++) table[I] = 0;

        // find the number of active players and if there is single active player, declare him to win
        int count = 0;
        int j;
        for (j=0;j<6;j++)
        {
            if (p[j].money <=0) count++;
        }
        if (count <= 1) break;


        //chose a dealer
        int dealer = i%6;
        dealer = (dealer==0)?6:dealer;
        while (1)
        {
            if (p[dealer-1].money <= 0)
            {
                dealer++;
                dealer = (dealer==7)?1:dealer;
            }
            else break;
        }
        
    
        // defining file input output streams
        ofstream myfile;
        fstream myf;
        ofstream dealfile;
        
        // prepare deal.txt file
        myfile.open("deal.txt", ios::out | ios::trunc);
        if (myfile.is_open())
        {
            myfile << "Dealer   " << dealer << endl;
            myfile << "Stage    " << "Pre_Flop" << endl;
            myfile << "Main_Pot " << "0" << endl;
            myfile << endl;
            myfile << "Pre_Flop" << endl << endl;
            myfile.close();
        }
        
        // prepare deals_money.txt file
        myfile.open("deals_money.txt", ios::out | ios::trunc);
        if (myfile.is_open())
        {
            myfile << "Deal      " << (i+1) << endl;
            for (j=0;j<5;j++)
            {
                myfile << (j+1) << " " << p[j].money << endl;
            }

            myfile << (j+1) << " " << p[j].money;
            myfile.close();
        }
        
        // initialising potmoney and curmoney of players
        potmoney = 0;
        for (j=0;j<6;j++) 
        {
            p[j].curmoney = 0;
            p[j].status = 'a';
        }
        
        // Pre_Flop stage
        Pre_Flop:
        
        minraise = 10;
        stagemoney = 0;
        for(j=0;j<6;j++) p[j].curstage = 0;
        myfile.open("deal.txt", ios::out | ios::app);
        if (myfile.is_open())
        {    
			
			deal_cards (dealer);
			
            // players before small blind
            pl = dealer + 1;
            pl = (pl > 6)?1:pl;
            
            while(1)
            {
                if (p[pl-1].money <= 0)
                {
                    myfile << pl << "    -" << endl;
                    pl++;
                    pl = (pl==7)?1:pl;
                }
                else break;
            }
            
            // small blind
            tr = 5;
            if (p[pl-1].money < 5) tr = p[pl-1].money;
            
            p[pl-1].money -= tr;
            stagemoney += tr;
            p[pl-1].curstage += tr;
            potmoney += tr;
            p[pl-1].curmoney += tr;
            
            dealfile.open("deal.txt");
            if (dealfile.is_open())
            {
                dealfile << "Dealer   " << dealer << endl;
                dealfile << "Stage    " << "Pre_Flop" << endl;
                dealfile << "Main_Pot " << potmoney << endl;
                dealfile.close();
            }
            myfile << pl << "    " << "Rise " << tr << endl;
            
            
            // players before big blind
            pl = pl + 1;
            pl = (pl > 6)?1:pl;
            
            while(1)
            {
                if (p[pl-1].money <= 0)
                {
                    myfile << pl << "    -" << endl;
                    pl++;
                    pl = (pl==7)?1:pl;
                }
                else break;
            }
            
            // big blind
            tr = 10;
            if (p[pl-1].money < 5) tr = p[pl-1].money;
            
            p[pl-1].money -= tr;
            stagemoney += tr;
            p[pl-1].curstage += tr;
            potmoney += tr;
            p[pl-1].curmoney += tr;
            
            dealfile.open("deal.txt");
            if (dealfile.is_open())
            {
                dealfile << "Dealer   " << dealer << endl;
                dealfile << "Stage    " << "Pre_Flop" << endl;
                dealfile << "Main_Pot " << potmoney << endl;
                dealfile.close();
            }
            myfile << pl << "    " << "Rise " << tr;
            
            // finding tc
            tc = find_tc (pl); 
            if (tc == pl || tc == 7) goto Flop;
            
            while(1)
            {
                pl = pl+1;
                pl = (pl > 6)?1:pl;
                
                // if the player is already fold or has no money, just insert a '-' in deal.txt file
                if (p[pl-1].status == 'f' || p[pl-1].money <= 0)
                {
                    myfile << endl << pl << "    -";
                    continue;
                }
                
                // prepare inputf.txt file
                myf.open ("inputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << p[pl-1].card1 << "        " << p[pl-1].card2 << "    " << pl << "    " << p[pl-1].curmoney;
                    myf.close();
                }
                    
                // clear outputf.txt
                myf.open ("outputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << "";
                    myf.close();
                }
                
                // call code of player pl if his money is greater than 0 and if he is not fold or if there are atleast two players
                run_program (pl-1);
                
                // read outputf.txt file
                myf.open ("outputf.txt", ios::in);
                if (myf.is_open())
                {
                    myf >> te;
                    myf.close();
                }
                
                // fold
                if (te == -10)
                {
                    p[pl-1].status = 'f';
                    myfile << endl << pl << "    " << "Fold " << p[pl-1].curstage;
                }
                
                // call
                else if (te == 0)
                {
                    tr = stagemoney;
                    if (p[pl-1].money < (stagemoney - p[pl-1].curstage)) tr = p[pl-1].money + p[pl-1].curstage;
                    myfile << endl << pl << "    " << "Call " << tr;
                    p[pl-1].money -= (tr - p[pl-1].curstage);
                    p[pl-1].curstage = tr;
                    p[pl-1].curmoney += (tr - p[pl-1].curstage);
                }
                
                // rise
                else 
                {
                    if (p[pl-1].money < te || te < (stagemoney - p[pl-1].curstage))
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else if(te < minraise && p[pl-1].money > te)
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else
                    {    
                        p[pl-1].money -= te;
                        p[pl-1].curstage += te;
                        p[pl-1].curmoney += te;
                        potmoney += (p[pl-1].curmoney - stagemoney);
                        stagemoney = p[pl-1].curstage + te;
                        minraise = (te>minraise)?te:minraise;
                        
                        dealfile.open("deal.txt");
                        if (dealfile.is_open())
                        {
                            dealfile << "Dealer   " << dealer << endl;
                            dealfile << "Stage    " << "Pre_Flop" << endl;
                            dealfile << "Main_Pot " << potmoney << endl;
                            dealfile.close();
                        }
                        myfile << endl << pl << "    " << "Rise " << p[pl-1].curstage;
                        
                        tc = find_tc (pl);
                    }
                }
                
                if (tc == pl || tc == 7) goto Flop;
            }
            myfile.close();
        }
        

        // Flop stage
        Flop:
        
        minraise = 10;
        stagemoney = 0;
        for(j=0;j<6;j++) p[j].curstage = 0;
        
        // prepare deal.txt file
        dealfile.open("deal.txt");
        if (dealfile.is_open())
        {
            dealfile << "Dealer   " << dealer << endl;
            dealfile << "Stage    " << "Flop" << endl;
            dealfile << "Main_Pot " << potmoney << endl;
            dealfile.close();
        }
        
        // SHUFFLE cards to get three cards in c1, c2, c3
        int c1 = table[0];
        int c2 = table[1];
        int c3 = table[2];
        
        dealfile.open("deal.txt", ios::out | ios::app);
        if (dealfile.is_open())
        {
            dealfile << endl << "End" << endl << endl;
            dealfile << "Flop" << endl;
            dealfile << c1 << "        " << c2 << "    " << c3 << endl;
            dealfile.close();
        }
        
        // if there is a single player or no players with money, then no entry to be done
        if (find_count() <= 1) goto Fourth_Street;
        
        myfile.open("deal.txt", ios::out | ios::app);
        if (myfile.is_open())
        {    
            pl = dealer;
            tc = find_tc (dealer+1);
            while(1)
            {
                pl = pl+1;
                pl = (pl > 6)?1:pl;
                
                // if the player is already fold or has no money, just insert a '-' in deal.txt file
                if (p[pl-1].status == 'f' || p[pl-1].money <= 0)
                {
                    myfile << endl << pl << "    -";
                    continue;
                }
                
                // prepare inputf.txt file
                myf.open ("inputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << p[pl-1].card1 << "        " << p[pl-1].card2 << "    " << pl << "    " << p[pl-1].curmoney;
                    myf.close();
                }
                    
                // clear outputf.txt
                myf.open ("outputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << "";
                    myf.close();
                }
                
                // call code of player pl if his money is greater than 0 and if he is not fold or if there are atleast two players
                run_program (pl-1);
                
                // read outputf.txt file
                myf.open ("outputf.txt", ios::in);
                if (myf.is_open())
                {
                    myf >> te;
                    myf.close();
                }
                
                // fold
                if (te == -10)
                {
                    p[pl-1].status = 'f';
                    myfile << endl << pl << "    " << "Fold " << p[pl-1].curstage;
                }
                
                // call
                else if (te == 0)
                {
                    tr = stagemoney;
                    if (p[pl-1].money < (stagemoney - p[pl-1].curstage)) tr = p[pl-1].money + p[pl-1].curstage;
                    myfile << endl << pl << "    " << "Call " << tr;
                    p[pl-1].money -= (tr - p[pl-1].curstage);
                    p[pl-1].curstage = tr;
                    p[pl-1].curmoney += (tr - p[pl-1].curstage);
                }
                
                // rise
                else 
                {
                    if (p[pl-1].money < te || te < (stagemoney - p[pl-1].curstage))
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else if(te < minraise && p[pl-1].money > te)
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else
                    {    
                        p[pl-1].money -= te;
                        p[pl-1].curstage += te;
                        p[pl-1].curmoney += te;
                        potmoney += (p[pl-1].curmoney - stagemoney);
                        stagemoney = p[pl-1].curstage + te;
                        minraise = (te>minraise)?te:minraise;
                        
                        dealfile.open("deal.txt");
                        if (dealfile.is_open())
                        {
                            dealfile << "Dealer   " << dealer << endl;
                            dealfile << "Stage    " << "Flop" << endl;
                            dealfile << "Main_Pot " << potmoney << endl;
                            dealfile.close();
                        }
                        myfile << endl << pl << "    " << "Rise " << p[pl-1].curstage;
                        
                        tc = find_tc (pl);
                    }
                }
                
                if (tc == pl || tc == 7) goto Fourth_Street;
            }
            myfile.close();
        }
        
        
        // Forth_Street stage
        Fourth_Street:
        
        minraise = 20;
        stagemoney = 0;
        for(j=0;j<6;j++) p[j].curstage = 0;
        
        // prepare deal.txt file
        dealfile.open("deal.txt");
        if (dealfile.is_open())
        {
            dealfile << "Dealer   " << dealer << endl;
            dealfile << "Stage    " << "Fourth_Street" << endl;
            dealfile << "Main_Pot " << potmoney << endl;
            dealfile.close();
        }
        
        // SHUFFLE cards to get a card in c1
        c1 = table[4];
        
        dealfile.open("deal.txt", ios::out | ios::app);
        if (dealfile.is_open())
        {
            dealfile << endl << "End" << endl << endl;
            dealfile << "Fourth_Street" << endl;
            dealfile << c1 << endl;
            dealfile.close();
        }
        
        // if there is a single player or no players with money, then no entry to be done
        if (find_count() <= 1) goto Fifth_Street;
        
        myfile.open("deal.txt", ios::out | ios::app);
        if (myfile.is_open())
        {    
            pl = dealer;
            tc = find_tc (dealer+1);
            while(1)
            {
                pl = pl+1;
                pl = (pl > 6)?1:pl;
                
                // if the player is already fold or has no money, just insert a '-' in deal.txt file
                if (p[pl-1].status == 'f' || p[pl-1].money <= 0)
                {
                    myfile << endl << pl << "    -";
                    continue;
                }
                
                // prepare inputf.txt file
                myf.open ("inputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << p[pl-1].card1 << "        " << p[pl-1].card2 << "    " << pl << "    " << p[pl-1].curmoney;
                    myf.close();
                }
                    
                // clear outputf.txt
                myf.open ("outputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << "";
                    myf.close();
                }
                
                // call code of player pl if his money is greater than 0 and if he is not fold or if there are atleast two players
                run_program (pl-1);
                
                // read outputf.txt file
                myf.open ("outputf.txt", ios::in);
                if (myf.is_open())
                {
                    myf >> te;
                    myf.close();
                }
                
                // fold
                if (te == -10)
                {
                    p[pl-1].status = 'f';
                    myfile << endl << pl << "    " << "Fold " << p[pl-1].curstage;
                }
                
                // call
                else if (te == 0)
                {
                    tr = stagemoney;
                    if (p[pl-1].money < (stagemoney - p[pl-1].curstage)) tr = p[pl-1].money + p[pl-1].curstage;
                    myfile << endl << pl << "    " << "Call " << tr;
                    p[pl-1].money -= (tr - p[pl-1].curstage);
                    p[pl-1].curstage = tr;
                    p[pl-1].curmoney += (tr - p[pl-1].curstage);
                }
                
                // rise
                else 
                {
                    if (p[pl-1].money < te || te < (stagemoney - p[pl-1].curstage))
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else if(te < minraise && p[pl-1].money > te)
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else
                    {    
                        p[pl-1].money -= te;
                        p[pl-1].curstage += te;
                        p[pl-1].curmoney += te;
                        potmoney += (p[pl-1].curmoney - stagemoney);
                        stagemoney = p[pl-1].curstage + te;
                        minraise = (te>minraise)?te:minraise;
                        
                        dealfile.open("deal.txt");
                        if (dealfile.is_open())
                        {
                            dealfile << "Dealer   " << dealer << endl;
                            dealfile << "Stage    " << "Fourth_Street" << endl;
                            dealfile << "Main_Pot " << potmoney << endl;
                            dealfile.close();
                        }
                        myfile << endl << pl << "    " << "Rise " << p[pl-1].curstage;
                        
                        tc = find_tc (pl);
                    }
                }
                
                if (tc == pl || tc == 7) goto Fifth_Street;
            }
            myfile.close();
        }
                                                         
                                                         
        // Fifth_Street stage
        Fifth_Street:
        
        minraise = 20;
        stagemoney = 0;
        for(j=0;j<6;j++) p[j].curstage = 0;
        
        // prepare deal.txt file
        dealfile.open("deal.txt");
        if (dealfile.is_open())
        {
            dealfile << "Dealer   " << dealer << endl;
            dealfile << "Stage    " << "Fifth_Street" << endl;
            dealfile << "Main_Pot " << potmoney << endl;
            dealfile.close();
        }
        
        // SHUFFLE cards to get a card in c1
        c1 = table[5];
        
        dealfile.open("deal.txt", ios::out | ios::app);
        if (dealfile.is_open())
        {
            dealfile << endl << "End" << endl << endl;
            dealfile << "Fifth_Street" << endl;
            dealfile << c1 << endl;
            dealfile.close();
        }
        
        // if there is a single player or no players with money, then no entry to be done
        if (find_count() <= 1) goto Show_Down;
        
        myfile.open("deal.txt", ios::out | ios::app);
        if (myfile.is_open())
        {    
            pl = dealer;
            tc = find_tc (dealer+1);
            while(1)
            {
                pl = pl+1;
                pl = (pl > 6)?1:pl;
                
                // if the player is already fold or has no money, just insert a '-' in deal.txt file
                if (p[pl-1].status == 'f' || p[pl-1].money <= 0)
                {
                    myfile << endl << pl << "    -";
                    continue;
                }
                
                // prepare inputf.txt file
                myf.open ("inputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << p[pl-1].card1 << "        " << p[pl-1].card2 << "    " << pl << "    " << p[pl-1].curmoney;
                    myf.close();
                }
                    
                // clear outputf.txt
                myf.open ("outputf.txt", ios::out | ios::trunc);
                if (myf.is_open())
                {
                    myf << "";
                    myf.close();
                }
                
                // call code of player pl if his money is greater than 0 and if he is not fold or if there are atleast two players
                run_program (pl-1);
                
                // read outputf.txt file
                myf.open ("outputf.txt", ios::in);
                if (myf.is_open())
                {
                    myf >> te;
                    myf.close();
                }
                
                // fold
                if (te == -10)
                {
                    p[pl-1].status = 'f';
                    myfile << endl << pl << "    " << "Fold " << p[pl-1].curstage;
                }
                
                // call
                else if (te == 0)
                {
                    tr = stagemoney;
                    if (p[pl-1].money < (stagemoney - p[pl-1].curstage)) tr = p[pl-1].money + p[pl-1].curstage;
                    myfile << endl << pl << "    " << "Call " << tr;
                    p[pl-1].money -= (tr - p[pl-1].curstage);
                    p[pl-1].curstage = tr;
                    p[pl-1].curmoney += (tr - p[pl-1].curstage);
                }
                
                // rise
                else 
                {
                    if (p[pl-1].money < te || te < (stagemoney - p[pl-1].curstage))
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else if(te < minraise && p[pl-1].money > te)
                    myfile << endl << pl << "     " << "Fold " << p[pl-1].curstage;
                    else
                    {    
                        p[pl-1].money -= te;
                        p[pl-1].curstage += te;
                        p[pl-1].curmoney += te;
                        potmoney += (p[pl-1].curmoney - stagemoney);
                        stagemoney = p[pl-1].curstage + te;
                        minraise = (te>minraise)?te:minraise;
                        
                        dealfile.open("deal.txt");
                        if (dealfile.is_open())
                        {
                            dealfile << "Dealer   " << dealer << endl;
                            dealfile << "Stage    " << "Fifth_Street" << endl;
                            dealfile << "Main_Pot " << potmoney << endl;
                            dealfile.close();
                        }
                        myfile << endl << pl << "    " << "Rise " << p[pl-1].curstage;
                        
                        tc = find_tc (pl);
                    }
                }
                
                if (tc == pl || tc == 7) goto Show_Down;
            }
            myfile.close();
        }
        
        Show_Down:
        
        //Decide who won.
        //Add money to respective players
        
        int player_rank[6];
        int player_hand[6];
        
        for (int I=0; I<6; I++) {
			player_rank[I] = 0;
			player_hand[I] = 0;
        }
        
        
        //consider card representations
        for (int I=0; I<6; I++) {
			
			if (p[I].curmoney <= 0) continue; // wasn't playing in the game
			//take the cards for this player & evaluate his hand
			int hand = evaluate_hand (p[I].card1, p[I].card2); //Implement this function
			if (I==0) player_rank[I] = 1;
			else player_rank[I] = player_rank[I-1]+1;
			for (int b=I-1; b>=0; b--) {
				if (hand > player_hand[b]) {
					int temp = player_rank[I];
					player_rank[I] = player_rank[b];
					player_rank[b] = temp;
				}
				else if (hand == player_hand[b]) {
					player_rank[I] = player_rank[b];
				}
				else break;
			}
			
		}
		//we now have an array of player_ranks
		int players_gone = 0;
		for (int I=0; I<6; I++) {
			int sum = 0;
			int money_that_he_can_win = p[player_rank[I]].money ;
			for (int c=I; c<6; c++) {
				int m2 = p[player_rank[c]].money;
				if (m2 >= money_that_he_can_win) {
					sum += money_that_he_can_win;
					p[player_rank[c]].money -= money_that_he_can_win;
				}
				else {
					sum += m2;
					p[player_rank[c]].money = 0;
				}
			}
			cout << "Player " << I << " won " << sum << endl;
		}
		
		for (int I=0; I<6; I++) {
			run_program (i);
		}
		
	}
}
